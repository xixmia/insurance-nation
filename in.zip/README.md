# Insurance Nation Website

## What is Insurance Nation?
We created this site.
## Why We Created This Website

## Our Goals for the Site

## How to Contribute

#### Non Technical Support
  - Diagnose bugs with the site and create and issue on github
  - Test the pages of the site and provide feedback to cgomez@xixmia.com
  
#### Technical Support
  - Dig through the issues and pick something your confident you can fix and create a branch.
  - Push fixes to the master branch when they are complete
  - Properly and clearly document changes in your commits
